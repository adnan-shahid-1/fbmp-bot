import os

os.system("pip install -r requirements.txt")
print('========= Successfully installed dependencies =========')
os.system('pause')